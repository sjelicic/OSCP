﻿using System;

namespace Watson
{
    public static class Info
    {
        public static void PrintLogo()
        {
            Console.WriteLine("  __    __      _                   ");
            Console.WriteLine(" / / /\\ \\ \\__ _| |_ ___  ___  _ __  ");
            Console.WriteLine(" \\ \\/  \\/ / _` | __/ __|/ _ \\| '_ \\ ");
            Console.WriteLine("  \\  /\\  / (_| | |_\\__ \\ (_) | | | |");
            Console.WriteLine("   \\/  \\/ \\__,_|\\__|___/\\___/|_| |_|");
            Console.WriteLine("                                   ");
            Console.WriteLine("                           v0.1    ");
            Console.WriteLine("                                   ");
            Console.WriteLine("                  Sherlock sucks...");
            Console.WriteLine("                   @_RastaMouse\r\n");
        }
    }
}